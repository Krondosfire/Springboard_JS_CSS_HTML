document.getElementById("task6").value = ""; // Ensure input is empty on page load
